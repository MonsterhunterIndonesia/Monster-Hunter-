---
name: 신규 차량 그래픽 제공(Offer new vehicle sprites)
about: 신규 차량에 대한 그래픽과 정보를 제공하는 이슈 (An issue for offering sprites and info for new
  vehicle)
title: '[New]'
labels: new car
assignees: ''

---

**그래픽 스프라이트(Graphic sprite):**
<!--
여기에 그래픽 스프라이트를 첨부하세요.
Please attach the graphic sprite here.
-->


**제안할 차량 제원(Suggest vehicle specification):**
| Property | Suggest value |
|--------|--------|
| 이름(Name in Korean) _(eg. ``KTX 산천``)_ | 이름 |
| 영문 이름(Name in English) _(eg. ``KTX Sancheon``)_ | Name |
| 코드(Code) _(eg. ``KTX2N``)_ | ``제안할_코드명`` |
| 운영 속력(Speed) _(eg. ``300km/h``)_ | 000 km/h |
| 설계 최고 속력(Designed max. speed) _(eg. ``330km/h``)_ | 000 km/h |
| 화물 수송량(Capacity) _(eg. ``100명``)_ | 00 |
| 출력(Power) _(eg. ``4400kW``)_ | 00kW |
| 중량(Weight) _(eg. ``136t``)_ | 00t |
| 도입연도(Introduction year) _(eg. ``2004``)_ | 1900 |
