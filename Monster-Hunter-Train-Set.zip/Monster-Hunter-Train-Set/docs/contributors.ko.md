 # 기여하신 분들
## **코드**
  * **TELK** ([@telk5093](https://github.com/telk5093), telk5093@gmail.com, http://telk.kr)
  * **EightonEight** ([@EightonEight](https://github.com/EightonEight))
  * **Coconut** ([@Coconut](https://github.com/CoconutKR))

## **그래픽**
  * **TELK** ([@telk5093](https://github.com/telk5093), telk5093@gmail.com, http://telk.kr)
  * **skyu** (skyu2947@gmail.com)
  * **라스(Las)** (wlq10000@naver.com)
  * **작가(Jakga)** (angryphw@naver.com)
  * **초저항(Chojeohang)** (yunggu7410@naver.com)
  * **오픈기차(Opentrain)** ([@opentrain](https://github.com/opentrain), gks3900@naver.com)
  * **kiwitree** ([@kiwitreekor](https://github.com/kiwitreekor))
  * **Nebula** ([@SerpensNebula](https://github.com/SerpensNebula))
  * **kimgas** ([@kimgas](https://github.com/kimgas))
  * **즉삭** ([@ChuoSpecialRapid201](https://github.com/ChuoSpecialRapid201))
  * **EightonEight** ([@EightonEight](https://github.com/EightonEight))
  * **JukjeonWani** ([@JukjeonWani](https://github.com/JukjeonWani))
  * **Coconut** ([@Coconut](https://github.com/CoconutKR))

  자세한 그래픽 기여는 [contributors_graphic.md](./contributors_graphic.md)에서 확인하실 수 있습니다.

## **번역**
  * **TELK** - 한국어, 영어 (영국, 미국), 일본어
