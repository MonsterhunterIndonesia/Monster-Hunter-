# Contributors
## **Code**
  * **TELK** ([@telk5093](https://github.com/telk5093), telk5093@gmail.com, http://telk.kr)
  * **EightonEight** ([@EightonEight](https://github.com/EightonEight))
  * **Coconut** ([@Coconut](https://github.com/CoconutKR))

## **Graphic**
  * **TELK** ([@telk5093](https://github.com/telk5093), telk5093@gmail.com, http://telk.kr)
  * **skyu** (skyu2947@gmail.com)
  * **Las** (wlq10000@naver.com)
  * **Jakga** (angryphw@naver.com)
  * **Chojeohang** (yunggu7410@naver.com)
  * **Opentrain** ([@opentrain](https://github.com/opentrain), gks3900@naver.com)
  * **kiwitree** ([@kiwitreekor](https://github.com/kiwitreekor))
  * **Nebula** ([@SerpensNebula](https://github.com/SerpensNebula))
  * **kimgas** ([@kimgas](https://github.com/kimgas))
  * **ChuoSpecialRapid201** ([@ChuoSpecialRapid201](https://github.com/ChuoSpecialRapid201))
  * **EightonEight** ([@EightonEight](https://github.com/EightonEight))
  * **JukjeonWani** ([@JukjeonWani](https://github.com/JukjeonWani))
  * **Coconut** ([@Coconut](https://github.com/CoconutKR))

  Detail graphic contributes can be found at [contributors_graphic.md](./contributors_graphic.md)

## **Translation**
  * **TELK** - Korean, English (UK, US), Japanese
